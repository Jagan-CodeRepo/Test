﻿'use strict';

var app = angular.module("myApp",["ngRoute","nya.bootstrap.select","ngMessages","ngTouch", "angucomplete-alt","ngScrollbars","ngMaterial","material.svgAssetsCache","ngAnimate","ui.bootstrap","angularGrid","ngTable","bw.paging"]);

/*** Routing - Start ***/
app.config(function($routeProvider) {
   // $locationProvider.hashPrefix("!");
    $routeProvider 
	.when("/dashboard", {
        templateUrl : "includes/views/dashboard.html"
    })
	.otherwise({
		 templateUrl : "includes/views/dashboard.html"
    });
});
/*** Routing - End ***/
app.controller("rootCtrl",function($scope){
	/*** Toggle Function - Start ***/
	$scope.toggle = function(){
		if ($scope.class == "collapsed")
		$scope.class = "expand";
		else
		$scope.class = "collapsed";
	};
	/*** Toggle Function - End ***/
	/*** Menu Mouse over - Start ***/
	$scope.showMegaMenu = function() {
		$scope.menuIsVisible = true; 
	};
	$scope.hideMegaMenu = function () {
		$scope.menuIsVisible = false;
	};
	/*** Menu Mouse over - End ***/
	/*** Left Menu - Role Change - Collpased View ***/
	$scope.roleMenuSection = false;
	$scope.showRoleMenu = function(){
		$scope.roleMenuSection = true; 
		$scope.notActive = "active";
	};
	$scope.hideRoleMenu = function(){
		$scope.roleMenuSection = false;  
		$scope.notActive = "";
	};
	$scope.activeleftMenu = 1
	$scope.activateMenu = function(a){
		$scope.activeleftMenu = a

	}
	/*** Left Menu - Role Change - Collpased View - End ***/
	$scope.selectedVal = 'Auditor'
	$scope.auditOption =['Audit Lead', 'Auditor/ Audit Specialist', 'Project Manager','Functional Head - Audit', 'Function Lead - DE Deployment', 'DE Deployment Lead','One Audit Administrator','Role 1','Role 2','Role 3','Role 4','Role 5'];
	$scope.selectOption = function(value){
		$scope.selectedVal = value;
		$scope.dropOpen = false;
	}
});
/*** rootCtrl - End ***/
/** Header role Change - Start **/
app.controller('headerCtrler', function ($scope) {
	$scope.selectedVal = 'Auditor'
	$scope.auditOption =['Audit Lead', 'Auditor/ Audit Specialist', 'Project Manager','Functional Head - Audit', 'Function Lead - DE Deployment', 'DE Deployment Lead','One Audit Administrator','Role 1','Role 2','Role 3','Role 4','Role 5'];
	$scope.selectOption = function(value){
		$scope.selectedVal = value;
		$scope.dropOpen = false;
	}
	$scope.largeData=false
	$scope.roleLength = $scope.auditOption.length
	if($scope.roleLength >5){$scope.largeData = true}
	else{$scope.largeData = false}
	$scope.modalScrollbarConfig = {
		theme: 'dark',
		scrollInertia: 500,
		setHeight: 218
	}
});
	/** Header role Change - End  **/
/** Dashboard - Start **/
app.controller('dashboardCtrl',['$scope','angularGridInstance', function ($scope,angularGridInstance)  {
	/** BX- Slider data - start **/
	$scope.docs = [{"stageName":"High Alert","score":"60", "type":"tab"},
						{"stageName":"Scope & Category","score":"70", "type":"tab"},
						{"stageName":"Kick - Off","score":"82", "type":"tab"},
						{"stageName":"PMR", "type":"tab","score":"145",},
						{"stageName":"Risk", "type":"tab", "score":"37",},
						{"stageName":"Findings", "score":"16","type":"tab"},
						{"stageName":"Codenizant","score":"59", "type":"tab"},
						{"stageName":"QoS","score":"60", "type":"tab"}];
	/** BX- Slider data - End **/	
	/** breadCrumb select **/
	$scope.dashboardVerticalOptions=['Vertical','HEALTHCARE','INTERNAL','RETAIL','TECHNOLOGY','BFS','EU','MANLOG']
	$scope.dashboardVertical = 'Vertical';
	$scope.dashboardPureVerticalOptions= ['Pure Vertical','HEALTHCARE','INTERNAL','RETAIL','TECHNOLOGY','BFS','EU','MANLOG']
	$scope.dashboardPureVertical = 'Pure Vertical'
	$scope.verticalOptions =['HEALTHCARE','INTERNAL','RETAIL','TECHNOLOGY','BFS','EU','MANLOG'];
	$scope.buOptions =['HEALTHCARE - NA','NORDICS','BENELUX','BFS - NA','ASEAN','JAPAN','LIFE SCIENCE - UK','GERMANY','ML - UK','RCG - NA'];
	$scope.subverticalOptions =['Administration-India','Marketing','RMG','CGS NA','BPO','SV02','NA - South East','NA - North East'];
	$scope.parentaccountOptions =['COGNIZANT ADMIN','COGNIZANT MARKETING','MOLINA','COGNIZANT GWFM','EMM GROUP','UHG','CTS','LIBERTY MUTUAL','ARBITRON','COVAD','CBEYOND','WELLS FARGO']
	$scope.allaccountOptions =['Cognizant Admin','Cognizant Marketing','Molina Healthcare, Inc.-BPO','Cognizant GWFM','Emm Group Inc','UHG IT','BPO Internal','Liberty Mutual Insurance Company','Arbitron - ODC','MegaPath, Inc.','Cbeyond Communications','Wells Fargo Community Banking','D & B Canada','Hess Corporation','JPMC Mortgage Bank - Shared Services','Aetna Inc - QES','Oracle America Inc.','Arrowood Indemnity Company']
	$scope.serviceLineOption =['Service Line','Service Line 1','Service Line 2'];
	$scope.projectCategoryOption = ['Project Category','Project Category 1', 'Project Category 2'];
	$scope.billabilityOption = ['Billability', 'Billability 1', 'Billability 2'];
	$scope.trackingPlatformOption =['Tracking Platform', 'Tracking Platform 1', 'Tracking Platform 2'];
	$scope.subSolutionAreaOption = ['Sub Solution Area', 'Sub Solution Area 1', 'Sub Solution Area 2'];
	$scope.scopeOption = ['Scope', 'Scope 1', 'Scope 2']
	
	/** breadCrumb select **/
	/*** Show/Hide Filter - Start ***/
	$scope.audithidefilter = true;
	$scope.filter = true;
	$scope.toggleFilter = function(){
		$scope.filter = !$scope.filter
	}
    $scope.$watch('filter', function(){
        $scope.toggleText = $scope.filter ? 'Show Filter' : 'Hide Filter';
		$scope.hidefilter = !$scope.hidefilter;
    })
	/*** Show/Hide Filter - End ***/
	/** Carousel - Tab - Start **/
	$scope.$on('gocarousel', function(evt, data) {			
			$scope.selectedIndex = data-1;			
	});
	$scope.$on('carouselhighlight', function(evt, data) {			
			$scope.selectedmenu=data-1;
	});
	/** Carousel - Tab - End **/
	$scope.closeWidget=function(){
		$scope.selectedIndex = -1;
		$scope.selectedmenu = -1;
	}
	 
	$scope.handleTab = function(tabCount, ctrlName){
		$scope.$broadcast('tabEvent', {'tabCount':tabCount, "ctrlName": ctrlName});
	}
}]);
/** Dashboard - End **/
/** High Alert - Ctrl - Start **/
app.controller('highAlertCtrl', function ($scope) {
	$scope.higAlertTable = [{"accId":"1200372", "esaId": "1000008452", "projName":"00-0004_2002931 QicLink Support 00-0004_2002931 QicLink Support","parameterInfo":"Service Excellence & Tools Usage Score", "projectOwner":"Kottigerhanumanthappa, Vanishree Vanishree Kottigerhanumanthapp"},
							{"accId":"1223422", "esaId": "1000008452", "projName":"0034279/80_2005443 QicLink Cus","parameterInfo":"# of Projects with Client Commitments","projectOwner":"Archakam, Archakam B H Krishna Deekshitu BALAJI HARI KRISHNA"},
							{"accId":"1211571", "esaId": "1000088010", "projName":"1015259_2004249 QNXT Release M","parameterInfo":"Contractual Commitments Effectiveness","projectOwner":"Kasibhatla Venkata, Subrahmanya Satya Sreenivas Subrahmanya"},	
							{"accId":"1215777", "esaId": "1000115779", "projName":"1015259_2005569 Micro-Dyn Bund","parameterInfo":"Service Excellence &amp Tools Usage Score","projectOwner":"RAMBALA, KASI VISWESWARA VENKATA SURYA GOPAL KRISHNA MURTHY"},
							{"accId":"1218877", "esaId": "1000082696", "projName":"1015259_2006079 Facets - Suppo","parameterInfo":"% Planned buffer & Senior Profiles","projectOwner":"Subramanya Sathya Anjaneya, Manikanta Alapati Naga Venkata"},
							{"accId":"1202659", "esaId": "1000092006", "projName":"1017223_3000175 QNXT - AR Main","parameterInfo":"Service Excellence & Tools Usage Score","projectOwner":"Sreerama Yashwin Gokavarapu, Sree Saran Sai Veera Venkata  "},
							{"accId":"1215193", "esaId": "1000003124", "projName":"1017223_3000175 QNXT - ClaimCh 1017223_3000175 ","parameterInfo":"Transition Extension Instance","projectOwner":"TALUPURU HANUMANTHA RAO, TALUPURU BHAVYA MANOGNA Manogna"},
							{"accId":"1215400", "esaId": "1000099345", "projName":"1017223_3000175 QNXT Maintenan","parameterInfo":"Service Delivery Performance","projectOwner":"YellethotadahalliGirijashankar, RAJA CHANDRA SHEKAR Y G"},
							{"accId":"1200950", "esaId": "1000004870", "projName":"13309_2005130 ClaimCheck Conne","parameterInfo":"PRA Deployment Effectiveness","projectOwner":"Jayamarinathan lelion. s, Perianayagam lelion. J lelion"},
							{"accId":"1200319", "esaId": "1000006173", "projName":"13309_2005130 Facets - NetworX","parameterInfo":"Product Quality Commitments","projectOwner":"Mukthinuthalapati, Ganesh Babu Venkata Abhyudaya Geetha"},
							{"accId":"1200035", "esaId": "1000081213", "projName":"13309_2005130 Facets - Support","parameterInfo":"Infrastructure Availability","projectOwner":"Kanamarlapudi, Nikhitha Sai Kanamarlapudi Nikhitha Sai"},
							{"accId":"1201662", "esaId": "1000099360", "projName":"13309_2005130 Facets NetworX P","parameterInfo":"Kick off meeting Compliance","projectOwner":"Lumine Rex Earnest Thanapal, Vinnie Albin Melba Lumine "},
							{"accId":"1214724", "esaId": "1000071184", "projName":"13385_3000132 QNXT Claims Work","parameterInfo":"Test Execution Productivity","projectOwner":"GOTHAI THOPPAPATTI KANAGARAJAN, PRAGHAJIEETH SHIYAMRAJ  "},
							{"accId":"1200071", "esaId": "1000078341", "projName":"13385_3000132 TriZetto Claim T","parameterInfo":"Transition Exit Commitments","projectOwner":"APPASAHEB, CHOUGULE ABHIJIT appasaheb bhupal chougule"},
							{"accId":"1215193", "esaId": "1000086598", "projName":"13385_3000132 TriZetto NetworX","parameterInfo":"Critical Metric Management","projectOwner":"Chinnaratha Ahamed Sharieff, Mohamed Sarafath Mansoor  "},
							{"accId":"1218876", "esaId": "1000092006", "projName":"13397_3000132 QNXT Core Soluti","parameterInfo":"Start Up Audit Compliance","projectOwner":"Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini"},
							{"accId":"1200071", "esaId": "1000078341", "projName":"KHSI_CS_SOW SWAT Hours QNXT Co","parameterInfo":"QE&A - Test effectiveness","projectOwner":"Mariasoosai Anthony Raj Joseph, John Sebastian Joseph  "},
							{"accId":"1207087", "esaId": "1000116047", "projName":"KSPA_CS_SOW EDM Staging Databa","parameterInfo":"End Customer Satisfaction","projectOwner":"Vaidya, K V R Prasanth Karanam Venkata R. Prasanth Va"}]
	/** Pagination - Start **/
	$scope.viewby = 10;
	$scope.totalItems = $scope.higAlertTable.length;
	$scope.currentPage = 1;
	$scope.itemsPerPage = $scope.viewby;	 
	$scope.maxSize = 4; //Number of pager buttons to show	
	$scope.$watch('currentPage', function(value) {
		$scope.tempLast = $scope.currentPage*$scope.itemsPerPage
		if($scope.tempLast>$scope.totalItems){$scope.tempLast = $scope.totalItems}
	});
	/** Pagination - End **/
	$scope.$on('tabEvent', function(e,obj) {  
		if(obj.ctrlName == "highAlertCtrl"){
			$scope.isSet(parseInt(obj.tabCount));
			$scope.setTab(parseInt(obj.tabCount));
		}else{
        	         
		}
    });
	/** Tab - Section - Start **/
	$scope.tab = 1;

    $scope.setTab = function(newTab){
      $scope.tab = newTab;
    };

    $scope.isSet = function(tabNum){
      return $scope.tab === tabNum;
    };
	/** Tab - Section - End **/
	/** Filter - Start **/
	$scope.toggleList = function(listNum){
		for(var i=1;i<=4;i++){
			if(i != listNum)
			{
				$scope['listOpen'+i] = true;
			}
			else{
				$scope['listOpen'+listNum] = !$scope['listOpen'+listNum];
			}
		}		
	};
	$scope.applyList = function(listNum){
		$scope['listOpen'+listNum] = true;
	};
   /** Filter - End **/
   $scope.highPrjTrend = function(listNum){
		for(var i=1;i<=5;i++){
			if(i != listNum)
			{
				$scope['highAlertProjTrend'+i] = true;
			}
			else{
				$scope['highAlertProjTrend'+listNum] = !$scope['highAlertProjTrend'+listNum];
			}
		}		
	};
	$scope.applyHighPrjTrend = function(listNum){
		$scope['highAlertProjTrend'+listNum] = true;
	};
  $scope.items = ['Vaidya, K V R Prasanth Karanam Venkata R. Prasanth Va','Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini', 'Value3', 'Value4', 'Value5'];
  $scope.selected = ['Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini'];
   /** Filter - End **/
  /** Check box - Start **/
  $scope.toggle = function (item, list) {
    var idx = list.indexOf(item);
    if (idx > -1) {
      list.splice(idx, 1);
    }
    else {
      list.push(item);
    }
  };

  $scope.exists = function (item, list) {
    return list.indexOf(item) > -1;
  };

  $scope.isIndeterminate = function() {
    return ($scope.selected.length !== 0 &&
        $scope.selected.length !== $scope.items.length);
  };

  $scope.isChecked = function() {
    return $scope.selected.length === $scope.items.length;
  };

  $scope.toggleAll = function() {
    if ($scope.selected.length === $scope.items.length) {
      $scope.selected = [];
    } else if ($scope.selected.length === 0 || $scope.selected.length > 0) {
      $scope.selected = $scope.items.slice(0);
    }
  };
  /** Check box - End **/
  
  /** Filter Scroll **/
	$scope.filterScrollbarConfig = {
		theme: 'dark',
		scrollInertia: 500,
		setHeight: 200
	}
  /** Filter Scroll - End **/
})
/** High Alert - Ctrl - End **/


/** Kick Off - Ctrl - Start **/
app.controller('kickOffCtrl', function ($scope) {
	$scope.higAlertTable = [{"accName":"WSE TRAINING CENTER (GUANGDONG) CO.LTD", "esaId": "1000008452", "projName":"00-0004_2002931 QicLink Support 00-0004_2002931 QicLink Support","parameterInfo":"Service Excellence & Tools Usage Score","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10},
							{"accName":"GLOBALFOUNDRIES Dresden ModuleOneLLC&Co", "esaId": "1000008452", "projName":"0034279/80_2005443 QicLink Cus","parameterInfo":"# of Projects with Client Commitments","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10},
							{"accName":"Vereniging Samenwerkende Algemene Zieke", "esaId": "1000088010", "projName":"1015259_2004249 QNXT Release M","parameterInfo":"Contractual Commitments Effectiveness","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 20},	
							{"accName":"Omani Qatari Telecommunications Company", "esaId": "1000115779", "projName":"1015259_2005569 Micro-Dyn Bund","parameterInfo":"Service Excellence &amp Tools Usage Score","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 40},
							{"accName":"ADITYA BIRLA FASHION AND RETAIL LIMITED", "esaId": "1000082696", "projName":"1015259_2006079 Facets - Suppo","parameterInfo":"% Planned buffer & Senior Profiles","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10},
							{"accName":"VISIONARY INTEGRATION PROFESSIONALS, LLC", "esaId": "1000092006", "projName":"1017223_3000175 QNXT - AR Main","parameterInfo":"Service Excellence &amp Tools Usage Score","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 12},
							{"accName":"Mondelez Deutschland Services GmbH&Co.KG", "esaId": "1000003124", "projName":"1017223_3000175 QNXT - ClaimCh 1017223_3000175 ","parameterInfo":"Transition Extension Instance","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 54},
							{"accName":"COMPAGNIE EUROPEENNE DE GARANTIES ET CAU", "esaId": "1000099345", "projName":"1017223_3000175 QNXT Maintenan","parameterInfo":"Service Delivery Performance","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 16},
							{"accName":"DUP:Telefónica O2 Germany GmbH & Co. OHG", "esaId": "1000004870", "projName":"13309_2005130 ClaimCheck Conne","parameterInfo":"PRA Deployment Effectiveness","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 423},
							{"accName":"UBSFundServices (Lux) S.A. Poland Branch", "esaId": "1000006173", "projName":"13309_2005130 Facets - NetworX","parameterInfo":"Product Quality Commitments","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 563},
							{"accName":"WSE TRAINING CENTER (GUANGDONG) CO., LTD", "esaId": "1000081213", "projName":"13309_2005130 Facets - Support","parameterInfo":"Infrastructure Availability","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 0},
							{"accName":"Globalfoundries Dresden Module OneLLC&KG", "esaId": "1000099360", "projName":"13309_2005130 Facets NetworX P","parameterInfo":"Kick off meeting Compliance","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 342},
							{"accName":"JPMorgan Chase Bank, N.A.,Singapore Brch", "esaId": "1000071184", "projName":"13385_3000132 QNXT Claims Work","parameterInfo":"Test Execution Productivity","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 123},
							{"accName":"BNP Paribas India Solutions Pvt. Limited", "esaId": "1000078341", "projName":"13385_3000132 TriZetto Claim T","parameterInfo":"Transition Exit Commitments","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 5446},
							{"accName":"The Royal Bank of Scotland Plc NL branch", "esaId": "1000086598", "projName":"13385_3000132 TriZetto NetworX","parameterInfo":"Critical Metric Management","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10},
							{"accName":"Univ of CA, San Francisco Medical Center", "esaId": "1000092006", "projName":"13397_3000132 QNXT Core Soluti","parameterInfo":"Start Up Audit Compliance","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10},
							{"accName":"SCOR Global Life Americas Reinsurance Co", "esaId": "1000078341", "projName":"KHSI_CS_SOW SWAT Hours QNXT Co","parameterInfo":"QE&A - Test effectiveness","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10},
							{"accName":"BNYM Asset Servicing - Corporate Actions", "esaId": "1000116047", "projName":"KSPA_CS_SOW EDM Staging Databa","parameterInfo":"End Customer Satisfaction","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10}]
	/** Pagination - Start **/
	$scope.viewby = 10;
	$scope.totalItems = $scope.higAlertTable.length;
	$scope.currentPage = 1;
	$scope.itemsPerPage = $scope.viewby;	 
	$scope.maxSize = 4; //Number of pager buttons to show	
	$scope.$watch('currentPage', function(value) {
		$scope.tempLast = $scope.currentPage*$scope.itemsPerPage
		if($scope.tempLast>$scope.totalItems){$scope.tempLast = $scope.totalItems}
	});
	/** Pagination - End **/
	$scope.$on('tabEvent', function(e,obj) {  
		if(obj.ctrlName == "kickOffCtrl"){
			$scope.isSet(parseInt(obj.tabCount));
			$scope.setTab(parseInt(obj.tabCount));
		}else{
        	         
		}
    });
	/** Tab - Section - Start **/
	$scope.tab = 1;
    $scope.setTab = function(newTab){
      $scope.tab = newTab;
    };

    $scope.isSet = function(tabNum){
      return $scope.tab === tabNum;
    };
	/** Tab - Section - End **/
	/** Filter - Start **/
	$scope.kickoffCont = function(listNum){
		for(var i=1;i<=6;i++){
			if(i != listNum)
			{
				$scope['kickoffCont'+i] = true;
			}
			else{
				$scope['kickoffCont'+listNum] = !$scope['kickoffCont'+listNum];
			}
		}		
	};
	$scope.applyKickoffCont = function(listNum){
		$scope['kickoffCont'+listNum] = true;
	};
	$scope.kickoffDue = function(listNum){
		for(var i=1;i<=6;i++){
			if(i != listNum)
			{
				$scope['kickoffDue'+i] = true;
			}
			else{
				$scope['kickoffDue'+listNum] = !$scope['kickoffDue'+listNum];
			}
		}		
	};
	$scope.applyKickoffDue = function(listNum){
		$scope['kickoffDue'+listNum] = true;
	};
	$scope.kickoffOverdue = function(listNum){
		for(var i=1;i<=6;i++){
			if(i != listNum)
			{
				$scope['kickoffOverdue'+i] = true;
			}
			else{
				$scope['kickoffOverdue'+listNum] = !$scope['kickoffOverdue'+listNum];
			}
		}		
	};
	$scope.applyKickoffOverdue = function(listNum){
		$scope['kickoffOverdue'+listNum] = true;
	};
  $scope.items = ['Vaidya, K V R Prasanth Karanam Venkata R. Prasanth Va',
  					'Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini', 'Value3', 'Value4', 'Value5'];
  $scope.selected = ['Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini'];
   /** Filter - End **/
  /** Check box - Start **/
  $scope.toggle = function (item, list) {
    var idx = list.indexOf(item);
    if (idx > -1) {
      list.splice(idx, 1);
    }
    else {
      list.push(item);
    }
  };

  $scope.exists = function (item, list) {
    return list.indexOf(item) > -1;
  };

  $scope.isIndeterminate = function() {
    return ($scope.selected.length !== 0 &&
        $scope.selected.length !== $scope.items.length);
  };

  $scope.isChecked = function() {
    return $scope.selected.length === $scope.items.length;
  };

  $scope.toggleAll = function() {
    if ($scope.selected.length === $scope.items.length) {
      $scope.selected = [];
    } else if ($scope.selected.length === 0 || $scope.selected.length > 0) {
      $scope.selected = $scope.items.slice(0);
    }
  };
  /** Check box - End **/
  
  /** Filter Scroll **/
	$scope.filterScrollbarConfig = {
		theme: 'dark',
		scrollInertia: 500,
		setHeight: 200
	}
  /** Filter Scroll - End **/
})
/** Kick Off - Ctrl - End **/
/** Scope Ctrl - Start **/
app.controller('scopeCtrl', function ($scope, ngTableParams, $filter,$q, $http) {
	$scope.largeDataSet=[];	
	$scope.higAlertTable = [{"accName":"WSE TRAINING CENTER (GUANGDONG) CO.LTD", "esaId": "1000008452", "projName":"00-0004_2002931 QicLink Support 00-0004_2002931 QicLink Support","parameterInfo":"Service Excellence & Tools Usage Score","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10, "pmName":"Kottigerhanumanthappa, Vanishree Vanishree Kottigerhanumanthapp"},
							{"accName":"GLOBALFOUNDRIES Dresden ModuleOneLLC&Co", "esaId": "1000008452", "projName":"0034279/80_2005443 QicLink Cus","parameterInfo":"# of Projects with Client Commitments","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10,"pmName":"Archakam, Archakam B H Krishna Deekshitu BALAJI HARI KRISHNA"},
							{"accName":"Vereniging Samenwerkende Algemene Zieke", "esaId": "1000088010", "projName":"1015259_2004249 QNXT Release M","parameterInfo":"Contractual Commitments Effectiveness","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 20,"pmName":"Kasibhatla Venkata, Subrahmanya Satya Sreenivas Subrahmanya"},	
							{"accName":"Omani Qatari Telecommunications Company", "esaId": "1000115779", "projName":"1015259_2005569 Micro-Dyn Bund","parameterInfo":"Service Excellence &amp Tools Usage Score","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 40,"pmName":"Subramanya Sathya Anjaneya, Manikanta Alapati Naga Venkata"},
							{"accName":"ADITYA BIRLA FASHION AND RETAIL LIMITED", "esaId": "1000082696", "projName":"1015259_2006079 Facets - Suppo","parameterInfo":"% Planned buffer & Senior Profiles","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10,"pmName":"Subramanya Sathya Anjaneya, Manikanta Alapati Naga Venkata"},
							{"accName":"VISIONARY INTEGRATION PROFESSIONALS, LLC", "esaId": "1000092006", "projName":"1017223_3000175 QNXT - AR Main","parameterInfo":"Service Excellence &amp Tools Usage Score","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 12, "pmName":"Sudha"},
							{"accName":"Mondelez Deutschland Services GmbH&Co.KG", "esaId": "1000003124", "projName":"1017223_3000175 QNXT - ClaimCh 1017223_3000175 ","parameterInfo":"Transition Extension Instance","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 54,"pmName":"Avinash"},
							{"accName":"COMPAGNIE EUROPEENNE DE GARANTIES ET CAU", "esaId": "1000099345", "projName":"1017223_3000175 QNXT Maintenan","parameterInfo":"Service Delivery Performance","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 16, "pmName":"Vaidya, K V R Prasanth Karanam Venkata R. Prasanth Va"},
							{"accName":"DUP:Telefónica O2 Germany GmbH & Co. OHG", "esaId": "1000004870", "projName":"13309_2005130 ClaimCheck Conne","parameterInfo":"PRA Deployment Effectiveness","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 423,"pmName":"Mariasoosai Anthony Raj Joseph, John Sebastian Joseph"},
							{"accName":"UBSFundServices (Lux) S.A. Poland Branch", "esaId": "1000006173", "projName":"13309_2005130 Facets - NetworX","parameterInfo":"Product Quality Commitments","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 563,"pmName":"Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini"},
							{"accName":"WSE TRAINING CENTER (GUANGDONG) CO., LTD", "esaId": "1000081213", "projName":"13309_2005130 Facets - Support","parameterInfo":"Infrastructure Availability","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 0,"pmName":"Kanamarlapudi, Nikhitha Sai Kanamarlapudi Nikhitha Sai"},
							{"accName":"Globalfoundries Dresden Module OneLLC&KG", "esaId": "1000099360", "projName":"13309_2005130 Facets NetworX P","parameterInfo":"Kick off meeting Compliance","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 342,"pmName":"GOTHAI THOPPAPATTI KANAGARAJAN, PRAGHAJIEETH SHIYAMRAJ  "},
							{"accName":"JPMorgan Chase Bank, N.A.,Singapore Brch", "esaId": "1000071184", "projName":"13385_3000132 QNXT Claims Work","parameterInfo":"Test Execution Productivity","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 123, "pmName":"Mukthinuthalapati, Ganesh Babu Venkata Abhyudaya Geetha"},
							{"accName":"BNP Paribas India Solutions Pvt. Limited", "esaId": "1000078341", "projName":"13385_3000132 TriZetto Claim T","parameterInfo":"Transition Exit Commitments","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 5446,"pmName":"TALUPURU HANUMANTHA RAO, TALUPURU BHAVYA MANOGNA Manogna"},
							{"accName":"The Royal Bank of Scotland Plc NL branch", "esaId": "1000086598", "projName":"13385_3000132 TriZetto NetworX","parameterInfo":"Critical Metric Management","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10,"pmName":"Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini"},
							{"accName":"Univ of CA, San Francisco Medical Center", "esaId": "1000092006", "projName":"13397_3000132 QNXT Core Soluti","parameterInfo":"Start Up Audit Compliance","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10,"pmName":"Jayamarinathan lelion. s, Perianayagam lelion. J lelion"},
							{"accName":"SCOR Global Life Americas Reinsurance Co", "esaId": "1000078341", "projName":"KHSI_CS_SOW SWAT Hours QNXT Co","parameterInfo":"QE&A - Test effectiveness","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10,"pmName":"Chinnaratha Ahamed Sharieff, Mohamed Sarafath Mansoor  "},
							{"accName":"BNYM Asset Servicing - Corporate Actions", "esaId": "1000116047", "projName":"KSPA_CS_SOW EDM Staging Databa","parameterInfo":"End Customer Satisfaction","projStartDate": "10-03-2017", "projPortedDate":"10-03-2017","pmId":"468033","ageingDays": 10,"pmName":"Sreerama Yashwin Gokavarapu, Sree Saran Sai Veera Venkata"}]
	
	$scope.filterSel={};
	$scope.filterSel.city=[];
	$scope.filterSel.state=[];
	$scope.filterData={};
	$scope.filterData.city=[];
	$scope.filterData.state=[];
	$scope.filterPage={};
	$scope.filterPage.city=1;
	$scope.filterPage.state=1;
	$scope.filterSearch={};
	$scope.filterSearch.city='';
	$scope.filterSearch.state='';
	$scope.filterPagedData={};
	$scope.filterPagedData.city=[];
	$scope.filterPagedData.state=[];
	$scope.tableFilter=function(column, prop){
		var def = $q.defer(),
        arr = [];
		arr=$filter('uniqueByProp')($scope.largeDataSet, prop);
		def.resolve(arr);
		return def;
	};
	$scope.toggleFilter = function (item, list) {
		var idx = list.indexOf(item);
		if (idx > -1) {
		  list.splice(idx, 1);
		}
		else {
		  list.push(item);
		}
	};
	$scope.existsFilter = function (item, list) {
		return list.indexOf(item) > -1;
	};
	$scope.filterApply=function(column,field){
		var filter = {};
		if($scope.filterSel[field].length>0){
			filter[field]=$scope.filterSel[field];
			filter['field']=field;
		}
		else
		{
			filter[field]='';
		}
		angular.extend($scope.tableParams.filter(), filter);
	};
	$scope.getfilterdata=function(list,column){
		
		var filteredarray=$filter('orderBy')(list);		
		filteredarray=$filter("filter")(filteredarray,$scope.filterSearch[column]);
		//$scope.filterpage[column]=1;
		$scope.filterPagedData[column]=filteredarray;
		//filteredarray=filteredarray.slice((($scope.filterPage[column]-1)*$scope.itemsperpage), (($scope.filterPage[column])*$scope.itemsperpage));					
		return filteredarray;
	};
	$scope.getPagedData = function(column,page) {
		var filteredArray=$scope.filterPagedData[column];
		$scope.filterPage[column]=page;
		filteredArray=filteredArray.slice((($scope.filterPage[column]-1)*$scope.itemsPerPage), (($scope.filterPage[column])*$scope.itemsPerPage));					
		return filteredArray;
	};
	var higAlertTable=$scope.largeDataSet;
	
	// function customNgTable(data)
	// {
		// this.customTableData=data;
		// this.table={};
		// this.loadData=function(data){
			// this.customTableData=data;
		// };
		// this.getCustomTableData=function(){
			// return this.data;
		// };
		// this.create = function(){
			// this.table=new ngTableParams({
						// id:1,
                        // page: 1,            // show first page
                        // count: 10           // count per page
                    // }, 
					// {
                        // total: customTableData.length, // length of data
                        // getData: function($defer, params) {
                            // // use built-in angular filter
                            // var orderedData = params.sorting() ? $filter('orderBy')(customTableData, params.orderBy()) : customTableData;
							// if(angular.isDefined(params.filter()) && angular.isDefined(params.filter()['field']))
							// {
								// orderedData = params.filter() ? $filter('inArray')(orderedData, params.filter()[params.filter()['field']],
								// params.filter()['field']) : orderedData;
							// }
							// else
							// {
								// orderedData = params.filter() ? $filter('filter')(orderedData, params.filter()) : orderedData;
							// }
							// params.total(orderedData.length);
                            // $defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                        // }
                    // });
			// return this.table;
		// };
	// };
	
	// $scope.test=new customNgTable($scope.largeDataSet);
	$scope.tableParams = new ngTableParams({
						id:1,
                        page: 1,            // show first page
                        count: 10           // count per page
                    }, 
					{
                        total: $scope.largeDataSet.length, // length of data
                        getData: function($defer, params) {
                            // use built-in angular filter
                            var orderedData = params.sorting() ? $filter('orderBy')($scope.largeDataSet, params.orderBy()) : $scope.largeDataSet;
							if(angular.isDefined(params.filter()) && angular.isDefined(params.filter()['field']))
							{
								orderedData = params.filter() ? $filter('inArray')(orderedData, params.filter()[params.filter()['field']],
								params.filter()['field']) : orderedData;
							}
							else
							{
								orderedData = params.filter() ? $filter('filter')(orderedData, params.filter()) : orderedData;
							}
							params.total(orderedData.length);
                            $defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                        }
                    });
	
	/** Pagination - Start **/
	$scope.viewby = 10;
	$scope.totalItems = $scope.higAlertTable.length;
	$scope.currentPage = 1;
	$scope.itemsPerPage = 10;	 
	$scope.maxSize = 3; //Number of pager buttons to show	
	// $scope.$watch('currentPage', function(value) {
		// console.log($scope.currentPage);
		// $scope.tempLast = $scope.currentPage*$scope.itemsPerPage
		// if($scope.tempLast>$scope.totalItems){$scope.tempLast = $scope.totalItems}
	// });
	/** Pagination - End **/
	$scope.$on('tabEvent', function(e,obj) {  
		if(obj.ctrlName == "scopeCtrl"){
			$scope.isSet(parseInt(obj.tabCount));
			$scope.setTab(parseInt(obj.tabCount));
		}else{
        	         
		}
    });
	/** Tab - Section - Start **/
	$scope.tab = 1;
    $scope.setTab = function(newTab){
      $scope.tab = newTab;
	  if(newTab===1)
	  {
		  $http.get("zips.json")
			.then(function(response) {
			   $scope.largeDataSet= response.data;
			   $scope.filterData.city=$filter('uniqueByProp')($scope.largeDataSet, 'city');
			   $scope.filterData.state=$filter('uniqueByProp')($scope.largeDataSet, 'state');
			   $scope.tableParams.reload();
			});
	  }
    };

    $scope.isSet = function(tabNum){
      return $scope.tab === tabNum;
    };
	/** Tab - Section - End **/
	/** Filter - Start **/
	$scope.scopeTab1 = function(listNum){
		for(var i=1;i<=6;i++){
			if(i != listNum)
			{
				$scope['scopeTab1'+i] = true;
			}
			else{
				$scope['scopeTab1'+listNum] = !$scope['scopeTab1'+listNum];
			}
		}		
	};
	$scope.applyScopeTab1 = function(listNum){
		$scope['scopeTab1'+listNum] = true;
	};
	$scope.scopeTab2 = function(listNum){
		for(var i=1;i<=6;i++){
			if(i != listNum)
			{
				$scope['scopeTab2'+i] = true;
			}
			else{
				$scope['scopeTab2'+listNum] = !$scope['scopeTab2'+listNum];
			}
		}		
	};
	$scope.applyScopeTab2 = function(listNum){
		$scope['scopeTab2'+listNum] = true;
	};
	$scope.scopeTab3 = function(listNum){
		for(var i=1;i<=6;i++){
			if(i != listNum)
			{
				$scope['scopeTab3'+i] = true;
			}
			else{
				$scope['scopeTab3'+listNum] = !$scope['scopeTab3'+listNum];
			}
		}		
	};
	$scope.applyScopeTab3 = function(listNum){
		$scope['scopeTab3'+listNum] = true;
	};
	$scope.scopeTab4 = function(listNum){
		for(var i=1;i<=6;i++){
			if(i != listNum)
			{
				$scope['scopeTab4'+i] = true;
			}
			else{
				$scope['scopeTab4'+listNum] = !$scope['scopeTab4'+listNum];
			}
		}		
	};
	$scope.applyScopeTab4 = function(listNum){
		$scope['scopeTab4'+listNum] = true;
	};
  $scope.items = ['Vaidya, K V R Prasanth Karanam Venkata R. Prasanth Va',
  					'Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini', 'Value3', 'Value4', 'Value5'];
  $scope.selected = ['Muthu Vairavan Pillai, Kamatchi Vinothini.M vinothini'];
   /** Filter - End **/
  /** Check box - Start **/
  $scope.toggle = function (item, list) {
    var idx = list.indexOf(item);
    if (idx > -1) {
      list.splice(idx, 1);
    }
    else {
      list.push(item);
    }
  };

  $scope.exists = function (item, list) {
    return list.indexOf(item) > -1;
  };

  $scope.isIndeterminate = function() {
    return ($scope.selected.length !== 0 &&
        $scope.selected.length !== $scope.items.length);
  };

  $scope.isChecked = function() {
    return $scope.selected.length === $scope.items.length;
  };

  $scope.toggleAll = function() {
    if ($scope.selected.length === $scope.items.length) {
      $scope.selected = [];
    } else if ($scope.selected.length === 0 || $scope.selected.length > 0) {
      $scope.selected = $scope.items.slice(0);
    }
  };
  /** Check box - End **/
  
  /** Filter Scroll **/
	$scope.filterScrollbarConfig = {
		theme: 'dark',
		scrollInertia: 500,
		setHeight: 200
	}
  /** Filter Scroll - End **/
})
/** Scope Ctrl - End **/
/** Directives - Start**/
/** BX-Slider Directive - Start **/
app.directive('bxSlider', function () {
	var BX_SLIDER_OPTIONS = {
		slideWidth:'160',
		//minSlides:6,
		maxSlides: 8,
		slideMargin: 10, 
		infiniteLoop: false,
		hideControlOnEnd: true,
		moveSlides:1,
		pager: false
	};

	return {
		restrict: 'A',
		require: 'bxSlider',
		priority: 0,
		controller: function() {},
		link: function (scope, element, attrs, ctrl) {
			var slider;
			ctrl.update = function() {
				slider && slider.destroySlider();
				slider = element.bxSlider(BX_SLIDER_OPTIONS);
			};
		}
	}
})
app.directive('bxSliderItem', function($timeout) {
	return {
		require: '^bxSlider',
		link: function(scope, elm, attr, bxSliderCtrl) {
			if (scope.$last) {
					bxSliderCtrl.update();
			}
		}
	}
})
app.directive('docListWrapper', ['$timeout','$rootScope', function ($timeout,$rootScope) {
	return {
		restrict: 'AEC',			
		priority: 500,
		replace: true,
		templateUrl: 'tmpl-doc-list-wrapper',
		scope: { docs: '=docs',
				 selectedmenu: '=selectedmenu'
			   },
		link: function (scope, element, attrs, ctrl) {
			scope.myclick = function(a,b){	
				if(b=='tab'){
					$rootScope.$broadcast('gocarousel', a);	
					$rootScope.$broadcast('carouselhighlight', a);	
				}
				else if(b == 'scroll'){
					$rootScope.$broadcast('gomain', a);						
					$rootScope.$broadcast('gotabCtrl', a);						
				}
				else{
					return;
				}
			}
		}
	};
}])
/** BX-Slider Directive - End **/
/*** Tooltip - Start ***/
app.directive('tooltip', function(){
	return {
		restrict: 'A',
		link: function(scope, element, attrs){
			$(element).hover(function(){
				// on mouseenter
				$(element).tooltip('show');
			}, function(){
				// on mouseleave
				$(element).tooltip('hide');
			});
		}
	};
});
/*** Tooltip - End ***/
/** Directives - End **/
app.filter("unique", function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
})
app.filter("uniqueByProp", function () {
    return function (collection, keyname) {
        var keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
            }
        });

        return keys;
    };
})
app.filter('inArray', function($filter){
    return function(list, arrayFilter, element){
        if(angular.isArray(arrayFilter) && arrayFilter.length>0){
            return $filter("filter")(list, function(listItem){
                return arrayFilter.indexOf(listItem[element]) != -1;
            });
        }
		else{
			return list;
		}
    };
})
app.filter('inObjArray', function($filter){
    return function(list, objFilter, element){
		var filteredArray=list;
		for(key in objFilter)
		{	arrayFilter=objFilter[key];		
			if( key !== element && angular.isArray(arrayFilter) && arrayFilter.length>0){
				filteredArray=$filter("filter")(list, function(listItem){
					return arrayFilter.indexOf(listItem[element]) != -1;
				});
			}
		}
		return filteredArray;
    };
})
app.filter('filterPagination', function($filter){
    return function(list, filter, currentPage, itemsPerPage){
		var filteredArray=$filter("filter")(list,filter);
		currentPage=filteredArray.length>0?1:currentPage;
		filteredArray=filteredArray.slice(((currentPage-1)*itemsPerPage), ((currentPage)*itemsPerPage));
		return filteredArray;
    };
})
app.filter('slice', function() {
  return function(arr, start, end) {
    return arr.slice(start, end);
  };
});