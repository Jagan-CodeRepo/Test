$(function () {    //e.preventDefault();
    var ul = $('.listing > ul');
    var ul2 = $('.listing > ul > li.open ul');
    // === Resize window related === //
    $(window).on('resize', function() {
        wwidth = $(window).width();
        if (wwidth >= 768 && wwidth <= 1024) {
            //$('.listing > ul > li.open ul').attr('style','').parent().removeClass('open');
            ul.css({
                'display': 'block'
            });
        }
        if (wwidth > 767) {
            ul.css({
                'display': 'block'
            });
            $('body').removeClass('menu-open');
            $('.listing').attr('style', '');
            $('#user-nav > ul').css({
                width: 'auto',
                margin: '0'
            });
        }
    });
    if ($(window).width() > 767) {
        ul.css({
            'display': 'block'
        });
    }
    if ($(window).width() > 767 && $(window).width() < 1024) {
        ul2.css({
            'display': 'none'
        });
    }
});
$(document).on('click', '.submenu > a', function(e) {
    //e.preventDefault();
    var submenu = $(this).siblings('ul');
    var li = $(this).parents('li');
    var submenus = $('.listing li.submenu ul');
    var submenus_parents = $('.listing li.submenu');
    if (li.hasClass('open')) {
        if (($(window).width() > 976) || ($(window).width() < 768)) {
            submenu.slideUp();
        } else {
            submenu.fadeOut(150);
        }
        li.removeClass('open');
        $(this).find("span.iconArrow.active").removeClass("active"); // added for arrow change
		$(this).find("span.iconArrow.active").removeClass("active");
    } else {
        if (($(window).width() > 976) || ($(window).width() < 768)) {
            submenus.slideUp();
            submenu.slideDown();
        } else {
            submenus.fadeOut(150);
            submenu.fadeIn(150);
        }
        submenus_parents.removeClass('open');
        submenus_parents.find("span.iconArrow").removeClass('active');
        li.addClass('open');
		$(this).find("span.iconArrow").addClass("active"); 	
    }
    //$('.listing').getNiceScroll().resize();
});




function equalHeight() {
    if ($('.mainContent').height() > $(".leftSec").height()) {
        $('.leftSec').height($('.mainContent').height());
    } else {
        $('.leftSec').height($('.leftSec').height());
    }
}


/**clear field**/
function clearTextBox(field, id) {
        if (field.defaultValue == field.value) {
            field.value = '';
            $("#" + id).css("color", "#2e2e2e");
            $("#" + id).css("font-style", "normal");

        } else if (field.value == '') {
            field.value = field.defaultValue;
            $("#" + id).css("color", "#828282");
            $("#" + id).css("font-style", "normal");
        }
    }
    /**clear field**/
/*** Left Nav - Role Change ***/
$(".mainTopMenu .dropdownSubMenu li a").click(function() {
    var selectedText = $(this).text();
	/*** Left Menu - Vertical Selection ***/
	if(selectedText=="Vertical"){
		$(".verticalSelectBox").show();
	}
	else{
		$(".verticalSelectBox").hide();
	}
	/*** Left Menu - Vertical Selection ***/
	var trimmedText = selectedText.substring(0,3);
	$(".mainTopMenu .dropdownSubMenu li a").removeClass("selected");
	$(this).addClass("selected");
    $(this).parents('.mainTopMenu ul.dropdownCont').find('li.submenu a span.role').html(selectedText);
	$(this).parents('.wrapper.toggleContent .mainTopMenu ul.dropdownCont').find('li.submenu a span.role').html(trimmedText);
    $(this).parents('.mainTopMenu ul.dropdownCont').find('li.submenu ul.dropdownSubMenu').hide();
    $(this).parents('.mainTopMenu ul.dropdownCont').find('li.submenu.open').removeClass("open");
	$(this).parents('.mainTopMenu ul.dropdownCont').find('li.submenu a .iconArrow.active').removeClass("active");
});

$(".mainProjectMenu .dropdownSubMenu li a").click(function() {
    var selectText = $(this).text();
	$(".mainProjectMenu .dropdownSubMenu li a").removeClass("selected");
	$(this).addClass("selected");
    $(this).parents('.mainProjectMenu ul.dropdownCont').find('li.submenu a span.role').html(selectText);
	$(this).parents('.wrapper.toggleContent .mainProjectMenu ul.dropdownCont').find('li.submenu a span.role').html("BU");
    $(this).parents('.mainProjectMenu ul.dropdownCont').find('li.submenu ul.dropdownSubMenu').hide();
    $(this).parents('.mainProjectMenu ul.dropdownCont').find('li.submenu.open').removeClass("open");
	$(this).parents('.mainProjectMenu ul.dropdownCont').find('li.submenu a .iconArrow.active').removeClass("active");
});



/*** Screen Resolution, Scroll ***/
function viewport() {
    var e = window,
        a = 'inner';
    if (!('innerWidth' in window)) {
        a = 'client';
        e = document.documentElement || document.body;
    }
    return {
        width: e[a + 'Width'],
        height: e[a + 'Height']
    };
}

$(document).ready(function() {
    equalHeight();
    res();
    $('#inner-content-div').css("overflow", "")
});

$(window).resize(function() {
	if(wid>=1025){
		res();
		equalHeight();
		//$('.wrapper').removeClass('toggleContent'); 
	}
});

function res() {
	//var wid= $(window).width();        //gives width excluding scrollbar
	wid = viewport().width;   
	if(wid >= 768 && wid <= 1024)	
	{
		  $( '.leftSec').show(); 		
		  $( '.leftSec').animate({"margin-left":"-185px"},"fast");	/*changed here for left nav animate*/
		  $('.toggleIcon').removeClass('active');
		  $('.leftSec').css("position","fixed");
		  $('.logoSec').hide();		
		  $('.helpToggle,.projectIDMenu,.helpLeftNav').css("visibility","hidden");//for Help files
		  $('.header').animate({"margin-left":"55px"},"fast");	/*changed here for left nav animate*/
		  $('.mainContent').animate({"margin-left":"55px"},"fast");	/*changed here for left nav animate*/
		  $( '.mainContent').addClass('toggle');
		  $( '.leftMenuToggle' ).addClass( 'toggle');
		  $( '.header h3' ).addClass( 'toggle');
		  $( 'body' ).addClass( 'toggle');
		  $( '.wrapper' ).addClass( 'toggle');
		  $('.wrapper').addClass('toggleContent');
		  $('.toggleIcon').unbind('click');
		  $('ul.collapseSubmenu').hide();
		  $('ul.dropdownCont li.submenu span.iconArrow').removeClass('active');	
		  /*** Left Role Selection ***/
		  $('.wrapper.toggleContent .mainProjectMenu .role').html("BU");
		  var selectedText = $(".mainTopMenu .dropdownSubMenu li a.selected").text();
		  var trimmedText = selectedText.substring(0,3);
		  $('.wrapper.toggleContent .mainTopMenu .role').html(trimmedText);	
		  /*** Left Role Selection ***/
		  $('.toggleIcon').click(function() 
		  {
				$('.wrapper').toggleClass('toggleContent');
				if($('.wrapper').hasClass('toggleContent'))
				{									  
				    $('.leftSec').animate({"margin-left":"-185px"},"fast");	/*changed here for left nav animate*/
					$('.logoSec').hide();
				    $('.toggleIcon').removeClass('active');
					$('.helpToggle,.projectIDMenu,.helpLeftNav').css("visibility","hidden");//for Help files
				    $('.header').animate({"margin-left":"55"},"fast");/*changed here for left nav animate*/
		            $('.mainContent').animate({"margin-left":"55"},"fast");	/*changed here for left nav animate*/	  
				    $('.mainContent' ).addClass( 'toggle' );
				    $('.toggleIcon' ).addClass( 'toggle' );
				    $('.header h3' ).addClass( 'toggle' );
				    $('.wrapper').addClass( 'toggle');
				    $('.logoSec').hide();
					//$('ul.collapseSubmenu').hide();	
					$('.wrapper.toggleContent .mainProjectMenu .role').html("BU");
					$('.wrapper.toggleContent .mainTopMenu .role').html(trimmedText);
					/*** Left Menu close - on clicking outside ***/
					$(".wrapper.toggleContent .mainContent").click(function(){
						$(".wrapper.toggleContent .submenu.open .collapseSubmenu,.wrapper.toggleContent .submenu.open .buMenu").slideUp(150);
						$(".wrapper.toggleContent .submenu.open .iconArrow.active").removeClass("active");
						$(".wrapper.toggleContent .submenu.open").removeClass("open");

					});						
				}
				else
				{
					
				   	$('.leftSec').animate({"margin-left":"0px"},"fast");/*changed here for left nav animate*/
				   	$('.logoSec').show();
				   	$('.toggleIcon').addClass('active');
				   	$('.helpToggle,.projectIDMenu,.helpLeftNav').css("visibility","visible");//for Help files
				    $('.header').animate({"margin-left":"240px"},"fast");/*changed here for left nav animate*/
		            $('.mainContent').animate({"margin-left":"240px"},"fast");/*changed here for left nav animate*/
				   	$('.mainContent' ).removeClass( 'toggle' );
				   	$('.toggleIcon' ).removeClass( 'toggle' );
				  	$('.header h3' ).removeClass( 'toggle' );
				  	$('.wrapper').removeClass( 'toggle');
				    $('.logoSec').show();
					var selectText = $(".mainProjectMenu .dropdownSubMenu li a.selected").text();
				    $('.mainProjectMenu .role').html(selectText);
					var selectedText = $(".mainTopMenu .dropdownSubMenu li a.selected").text();
				    $('.mainTopMenu .role').html(selectedText);
					
				} 
				resizeTable();  
		 });		
		
	}

	else
	{	
		  $( '.leftSec').show(); 
		  $( '.leftSec').animate({"margin-left":"0px"},"fast");	/*changed here for left nav animate*/
		  $('.logoSec').show();
		  $('.toggleIcon').addClass('active');
		  $('.leftSec').css("position","fixed");
		  $('.header').animate({"margin-left":"240px"},"fast");	/*changed here for left nav animate*/
		  $('.mainContent').animate({"margin-left":"240px"},"fast");/*changed here for left nav animate*/	 
		  $( '.mainContent').removeClass('toggle');
		  $( '.toggleIcon' ).removeClass( 'toggle');
		  $( '.header h3' ).removeClass( 'toggle');
		  $( 'body' ).removeClass( 'toggle');
		  $( '.wrapper' ).removeClass( 'toggle');
		  $('.wrapper').removeClass('toggleContent');
		  $('.toggleIcon').unbind('click');
		  $('.wrapper.toggleContent .mainProjectMenu .role').html("BU");
		  $('.toggleIcon').click(function() 
		  {			
			   /*** Left Role Selection ***/
			    var selectedText = $(".mainTopMenu .dropdownSubMenu li a.selected").text();
			    var trimmedText = selectedText.substring(0,3);
			    $('.wrapper.toggleContent .mainTopMenu .role').html(trimmedText);
				/*** Left Role Selection ***/	
			    $('.wrapper').toggleClass('toggleContent');
				if($('.wrapper').hasClass('toggleContent'))
				{
				   $('.leftSec').animate({"margin-left":"-185px"},"fast");	/*changed here for left nav animate*/
				   $('.toggleIcon').removeClass('active');
				   $('.header').animate({"margin-left":"55px"},"fast");	/*changed here for left nav animate*/
		           $('.mainContent').animate({"margin-left":"55px"},"fast");/*changed here for left nav animate*/			  
				   $('.mainContent' ).addClass( 'toggle' );
				   $('.toggleIcon' ).addClass( 'toggle' );
				   $('.headerSec h3' ).addClass( 'toggle' );
				   $('.wrapper').addClass( 'toggle');
				   $('.logoSec').hide();
				   //$('ul.collapseSubmenu').hide();
				   $('.wrapper.toggleContent .mainProjectMenu .role').html("BU");
				   $('.wrapper.toggleContent .mainTopMenu .role').html(trimmedText);
				   /*** Left Menu close - on clicking outside ***/
					$(".wrapper.toggleContent .mainContent").click(function(){
						$(".wrapper.toggleContent .submenu.open .collapseSubmenu,.wrapper.toggleContent .submenu.open .buMenu").slideUp(150);
						$(".wrapper.toggleContent .submenu.open .iconArrow.active").removeClass("active");
						$(".wrapper.toggleContent .submenu.open").removeClass("open");
					});						
				}
				else
				{
				   $('.leftSec').animate({"margin-left":"0px"},"fast");/*changed here for left nav animate*/
				   $('.toggleIcon').addClass('active');
				   $('.header').animate({"margin-left":"240px"},"fast");/*changed here for left nav animate*/
		           $('.mainContent').animate({"margin-left":"240px"},"fast");/*changed here for left nav animate*/
				   $('.mainContent' ).removeClass( 'toggle' );
				   $('.toggleIcon' ).removeClass( 'toggle' );
				   $('.header h3' ).removeClass( 'toggle' );
				   $('.wrapper').removeClass( 'toggle');
				   $('.logoSec').show(); 
				   var selectText = $(".mainProjectMenu .dropdownSubMenu li a.selected").text();
				   $('.mainProjectMenu .role').html(selectText);
				   var selectedText = $(".mainTopMenu .dropdownSubMenu li a.selected").text();
				   $('.mainTopMenu .role').html(selectedText);
				}   
				resizeTable();
				sliderAlign();
		 });		 
	}
   
}

$(document).ready(function() {
<!-- Scroll Up -->
/*$(function () {
	$.scrollUp({
		scrollName: 'scrollUp', // Element ID
		scrollDistance: 700, // Distance from top/bottom before showing element (px)
		scrollFrom: 'top', // 'top' or 'bottom'
		scrollSpeed: 300, // Speed back to top (ms)
		easingType: 'linear', // Scroll to top easing (see http://easings.net/)
		animation: 'fade', // Fade, slide, none
		animationInSpeed: 200, // Animation in speed (ms)
		animationOutSpeed: 200, // Animation out speed (ms)
		scrollText: 'Top', // Text for element, can contain HTML
		scrollTitle: false, // Set a custom <a> title if required. Defaults to scrollText
		scrollImg: false, // Set true to use image
		activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
		zIndex: 2147483647 // Z-Index for the overlay
	});
}); */

<!-- Scroll Up -->
/* $(".dropdownSubMenu.buMenu.menuList").mCustomScrollbar({
	scrollEasing:"easeOutCirc", 
	autoDraggerLength:true,   
	advanced:{  
		updateOnBrowserResize:true,   
		updateOnContentResize:true   
	}	
});*/
$('.dropdown-menu input[type=text]').click(function(e){
	e.stopPropagation();
});
})