// JavaScript Document
$(document).ready(function(){
		/*** Select Box ***/
		 $('.selectpicker').selectpicker();
		/*** Select Box ***/
		 $(function () {
			 $('.date11').datepicker({ clearBtn: true, autoclose: true, todayHighlight: true, startDate: '-0d', dateFormat: 'yyyy-mm-dd'});
		 });
		 $(function () {
			 $('.date12').datepicker({ clearBtn: true, autoclose: true, todayHighlight: true, startDate: '+1d', dateFormat: 'yyyy-mm-dd'});
		 });
		 $(function () {
			 $('.date13').datepicker({ clearBtn: true, autoclose: true, todayHighlight: true, startDate: '+1d', dateFormat: 'yyyy-mm-dd'});
		 });
 
 
  $('.prjDetActive span.calIcon').click(function(){
	 $('.prjDetActive').hide();
	 $('.prjDetView').show();
	 $('.billDetInactive').hide();
	 $('.billDetActive').show();
	 $('.billDetView').hide();
 })
 
 $('.talentDetBtn').click(function(){
	 $('.billDetActive').hide();
	 $('.billDetView').show();
	 $('.talentDetInactive').hide();
	 $('.talentDetActive').show();
	 $('.talentDetView').hide();
 })
 
 $('.commentBtn').click(function(){
	  $('.talentDetActive').hide();
	  $('.talentDetView').show();
	  $('.commentInactive').hide();
	  $('.commentActive').show();
	  $('.commentView').hide();
 })
 
 $('.previewBtn').click(function(){
	 $('.prjDetActive').hide();
	 $('.prjDetInactive').hide();
	 $('.prjDetView').hide();
	 $('.billDetInactive').hide();
	 $('.billDetActive').hide();
	 $('.billDetView').hide();
	 $('.talentDetInactive').hide();
	 $('.talentDetActive').hide();
	 $('.talentDetView').hide();
	 $('.commentInactive').hide(); 
	 $('.commentActive').hide();
	 $('.commentView').hide();
	 $('.prevSecBtns').show();
	 $('.requestPage h4.subHeader').addClass('prevHeading').text('10000043578-Project ID/Name');
	 $('.completePrevForm').show();
	 $('.frmBtmCont').hide();
	 
 })
 
 $('.prjDetView').click(function(){
	 $(this).hide();
	 $('.prjDetActive').show();
 })
 $('.billDetView').click(function(){
	 $(this).hide();
	 $('.billDetActive').show();
 })
 $('.talentDetView').click(function(){
	 $(this).hide();
	 $('.talentDetActive').show();
 })
 $('.commentView').click(function(){
	 $(this).hide();
	 $('.commentActive').show();
 })
   
 $(".projectKey").keydown(function (e) {
  if (e.keyCode == 13) {
     $('.prjDetActive').hide();
	 $('.prjDetView').show();
	 $('.billDetInactive').hide();
	 $('.billDetActive').show();
	 $('.billDetView').hide();
  }
});

$('.billDetView,.talentDetView,.prjDetView').mouseenter(function(){
	$(this).css("background-color","#f2f2f2");
	$(this).find('.panel-heading').css('background-color','#f2f2f2');
})
$('.billDetView,.talentDetView,.prjDetView').mouseleave(function(){
	$(this).css("background-color","#ffffff");
	$(this).find('.panel-heading').css('background-color','#ffffff');
})

$(document).on('click', '.okModal',function () {
	$("#clarificationModal").hide();
	$("#closeRequestModal").hide();
	$('.modal-backdrop.in').css("opacity",0);
});

$('.requestTileView .prjDetView').click(function(){
	 $('.prjDetActive').hide();
	 $('.prjDetView').show();
})
$('.belDetActiveSaveBtn').click(function(){
	$('.billDetActive').hide();
	$('.billDetView').show();
})
$('.talentDetActiveSave').click(function(){
	$('.talentDetActive').hide();
	$('.talentDetView').show();
})


$('.cancelPreview').click(function(){
	$('.completePrevForm').hide();
	$('.prjDetView').show();
	$('.billDetView').show();
	$('.talentDetView').show();
	$('.commentView').show();
	$('.frmBtmCont').show();
})
/******** Added on 29/08/2016 ************/

$('#projectId').on('change',function(){
	 $('.prjDetActive').hide();
	 $('.prjDetView').show();
	 $('.billDetInactive').hide();
	 $('.billDetActive').show();
	 $('.billDetView').hide();
});


$(function(){
    $('#slimScrollDiv').slimScroll({
        height: '400px',
		size: '5px',
		distance:'5px',
		alwaysVisible:true
    });
});
})
/*** Box Highlight ***/
	jQuery(function($) {
	  // /////
	  // CLEARABLE INPUT
	  function tog(v){return v?'addClass':'removeClass';} 
	  $(document).on('input', '.clearable', function(){
		$(this)[tog(this.value)]('x');
	  }).on('mousemove', '.x', function( e ){
		$(this)[tog(this.offsetWidth-18 < e.clientX-this.getBoundingClientRect().left)]('onX');   
	  }).on('touchstart click', '.onX', function( ev ){
		ev.preventDefault();
		$(this).removeClass('x onX').val('').change();
	  });
	});
