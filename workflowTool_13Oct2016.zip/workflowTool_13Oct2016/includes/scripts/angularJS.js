﻿var app = angular.module('main', ['ngTable']);

app.directive('fixedTableHeaders', ['$timeout', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            $timeout(function () {
                var container = element.parentsUntil(attrs.fixedTableHeaders);
                element.stickyTableHeaders({ scrollableArea: container, "fixedOffset":-2});
            }, 0);
        }
    }
}]);

app.controller('MainCtrl', function ($scope, $filter, ngTableParams) {
    $scope.users = [{
        "ProjectDetails": "Thoughtstorm",
        "AccountDetails": "Biodex",
        "RFDID": "129",
        "FromDate": "2016-05-06",
        "DaysPending": 6,
        "SOID": 10,
        "Status": "Orange"
    }, {
        "ProjectDetails": "Linkbridge",
        "AccountDetails": "Mat Lam Tam",
        "RFDID": "78",
        "FromDate": "2015-11-09",
        "DaysPending": 8,
        "SOID": 2,
        "Status": "Red"
    }, {
        "ProjectDetails": "Eayo",
        "AccountDetails": "Ventosanzap",
        "RFDID": "0701",
        "FromDate": "2016-08-13",
        "DaysPending": 5,
        "SOID": 9,
        "Status": "Green"
    }, {
        "ProjectDetails": "Brainbox",
        "AccountDetails": "Home Ing",
        "RFDID": "4",
        "FromDate": "2016-06-14",
        "DaysPending": 1,
        "SOID": 6,
        "Status": "Grey"
    }, {
        "ProjectDetails": "Youtags",
        "AccountDetails": "Toughjoyfax",
        "RFDID": "00297",
        "FromDate": "2016-02-05",
        "DaysPending": 1,
        "SOID": 1,
        "Status": ""
    }, {
        "ProjectDetails": "Kamba",
        "AccountDetails": "Tampflex",
        "RFDID": "45559",
        "FromDate": "2015-10-29",
        "DaysPending": 5,
        "SOID": 8,
        "Status": ""
    }, {
        "ProjectDetails": "Blogpad",
        "AccountDetails": "Andalax",
        "RFDID": "34",
        "FromDate": "2016-01-14",
        "DaysPending": 2,
        "SOID": 8,
        "Status": ""
    }, {
        "ProjectDetails": "Zoonoodle",
        "AccountDetails": "Sub-Ex",
        "RFDID": "8192",
        "FromDate": "2015-11-28",
        "DaysPending": 8,
        "SOID": 8,
        "Status": ""
    }/*, {
        "ProjectDetails": "Oyoyo",
        "AccountDetails": "Zathin",
        "RFDID": "84622",
        "FromDate": "2015-11-05",
        "DaysPending": 1,
        "SOID": 5,
        "Status": ""
    }, {
        "ProjectDetails": "Jetwire",
        "AccountDetails": "Tresom",
        "RFDID": "5945",
        "FromDate": "2015-10-09",
        "DaysPending": 10,
        "SOID": 8,
        "Status": "Orange"
    }, {
        "ProjectDetails": "Brainbox",
        "AccountDetails": "Prodder",
        "RFDID": "7070",
        "FromDate": "2015-09-07",
        "DaysPending": 10,
        "SOID": 5,
        "Status": "Red"
    }, {
        "ProjectDetails": "Roomm",
        "AccountDetails": "Bitchip",
        "RFDID": "43672",
        "FromDate": "2016-04-10",
        "DaysPending": 5,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Dynava",
        "AccountDetails": "Y-find",
        "RFDID": "4",
        "FromDate": "2016-01-16",
        "DaysPending": 7,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Avaveo",
        "AccountDetails": "Stim",
        "RFDID": "99570",
        "FromDate": "2016-07-29",
        "DaysPending": 8,
        "SOID": 1,
        "Status": ""
    }, {
        "ProjectDetails": "Tanoodle",
        "AccountDetails": "Tin",
        "RFDID": "907",
        "FromDate": "2016-08-06",
        "DaysPending": 2,
        "SOID": 8,
        "Status": ""
    }, {
        "ProjectDetails": "Ooba",
        "AccountDetails": "Flowdesk",
        "RFDID": "37393",
        "FromDate": "2016-07-18",
        "DaysPending": 5,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Twinte",
        "AccountDetails": "Regrant",
        "RFDID": "6366",
        "FromDate": "2016-08-17",
        "DaysPending": 6,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Edgeclub",
        "AccountDetails": "Opela",
        "RFDID": "9310",
        "FromDate": "2015-12-25",
        "DaysPending": 5,
        "SOID": 6,
        "Status": ""
    }, {
        "ProjectDetails": "Voonte",
        "AccountDetails": "Gembucket",
        "RFDID": "063",
        "FromDate": "2015-11-30",
        "DaysPending": 8,
        "SOID": 6,
        "Status": ""
    }, {
        "ProjectDetails": "Linkbuzz",
        "AccountDetails": "Zamit",
        "RFDID": "469",
        "FromDate": "2016-06-23",
        "DaysPending": 1,
        "SOID": 3,
        "Status": ""
    }, {
        "ProjectDetails": "Rooxo",
        "AccountDetails": "Keylex",
        "RFDID": "569",
        "FromDate": "2015-09-04",
        "DaysPending": 7,
        "SOID": 4,
        "Status": ""
    }, {
        "ProjectDetails": "Jatri",
        "AccountDetails": "Overhold",
        "RFDID": "34",
        "FromDate": "2015-12-09",
        "DaysPending": 4,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Flipstorm",
        "AccountDetails": "Bamity",
        "RFDID": "1",
        "FromDate": "2016-05-05",
        "DaysPending": 8,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Bubblebox",
        "AccountDetails": "Flexidy",
        "RFDID": "574",
        "FromDate": "2016-03-07",
        "DaysPending": 5,
        "SOID": 3,
        "Status": ""
    }, {
        "ProjectDetails": "Chatterbridge",
        "AccountDetails": "Kanlam",
        "RFDID": "9784",
        "FromDate": "2016-04-25",
        "DaysPending": 8,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Fivechat",
        "AccountDetails": "Y-Solowarm",
        "RFDID": "5",
        "FromDate": "2016-08-12",
        "DaysPending": 9,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Oyope",
        "AccountDetails": "Stringtough",
        "RFDID": "1",
        "FromDate": "2016-06-18",
        "DaysPending": 5,
        "SOID": 4,
        "Status": ""
    }, {
        "ProjectDetails": "Vitz",
        "AccountDetails": "Job",
        "RFDID": "69",
        "FromDate": "2015-09-11",
        "DaysPending": 5,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Skiba",
        "AccountDetails": "Sonair",
        "RFDID": "44971",
        "FromDate": "2016-01-13",
        "DaysPending": 4,
        "SOID": 5,
        "Status": ""
    }, {
        "ProjectDetails": "Livepath",
        "AccountDetails": "Matsoft",
        "RFDID": "91436",
        "FromDate": "2015-10-01",
        "DaysPending": 2,
        "SOID": 6,
        "Status": ""
    }, {
        "ProjectDetails": "Skidoo",
        "AccountDetails": "Trippledex",
        "RFDID": "1",
        "FromDate": "2016-04-21",
        "DaysPending": 4,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Kimia",
        "AccountDetails": "Quo Lux",
        "RFDID": "41",
        "FromDate": "2016-02-19",
        "DaysPending": 2,
        "SOID": 6,
        "Status": ""
    }, {
        "ProjectDetails": "Yotz",
        "AccountDetails": "Alphazap",
        "RFDID": "9",
        "FromDate": "2016-06-13",
        "DaysPending": 2,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Quinu",
        "AccountDetails": "Opela",
        "RFDID": "394",
        "FromDate": "2016-05-20",
        "DaysPending": 1,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Mynte",
        "AccountDetails": "Flowdesk",
        "RFDID": "08071",
        "FromDate": "2016-02-04",
        "DaysPending": 7,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Yamia",
        "AccountDetails": "Tin",
        "RFDID": "8425",
        "FromDate": "2016-01-12",
        "DaysPending": 10,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "InnoZ",
        "AccountDetails": "Zontrax",
        "RFDID": "3",
        "FromDate": "2015-11-22",
        "DaysPending": 4,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Centimia",
        "AccountDetails": "Mat Lam Tam",
        "RFDID": "00945",
        "FromDate": "2016-02-05",
        "DaysPending": 1,
        "SOID": 3,
        "Status": ""
    }, {
        "ProjectDetails": "Gabtype",
        "AccountDetails": "Cardify",
        "RFDID": "1520",
        "FromDate": "2016-02-04",
        "DaysPending": 4,
        "SOID": 3,
        "Status": "Green"
    }, {
        "ProjectDetails": "Youspan",
        "AccountDetails": "Daltfresh",
        "RFDID": "97",
        "FromDate": "2016-05-22",
        "DaysPending": 7,
        "SOID": 4,
        "Status": ""
    }, {
        "ProjectDetails": "Topiczoom",
        "AccountDetails": "Flexidy",
        "RFDID": "20788",
        "FromDate": "2016-01-16",
        "DaysPending": 8,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Voonix",
        "AccountDetails": "Mat Lam Tam",
        "RFDID": "79417",
        "FromDate": "2015-09-03",
        "DaysPending": 6,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Wikido",
        "AccountDetails": "Temp",
        "RFDID": "64715",
        "FromDate": "2015-12-23",
        "DaysPending": 2,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Realcube",
        "AccountDetails": "Viva",
        "RFDID": "43",
        "FromDate": "2016-06-16",
        "DaysPending": 10,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Jatri",
        "AccountDetails": "Transcof",
        "RFDID": "9",
        "FromDate": "2015-10-29",
        "DaysPending": 10,
        "SOID": 10,
        "Status": "Green"
    }, {
        "ProjectDetails": "Eayo",
        "AccountDetails": "Subin",
        "RFDID": "24",
        "FromDate": "2016-04-01",
        "DaysPending": 7,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Dablist",
        "AccountDetails": "Toughjoyfax",
        "RFDID": "08",
        "FromDate": "2015-12-23",
        "DaysPending": 6,
        "SOID": 5,
        "Status": "Red"
    }, {
        "ProjectDetails": "BlogXS",
        "AccountDetails": "Treeflex",
        "RFDID": "11197",
        "FromDate": "2015-11-16",
        "DaysPending": 10,
        "SOID": 8,
        "Status": ""
    }, {
        "ProjectDetails": "Dynava",
        "AccountDetails": "Namfix",
        "RFDID": "57603",
        "FromDate": "2016-06-20",
        "DaysPending": 6,
        "SOID": 1,
        "Status": ""
    }, {
        "ProjectDetails": "Topicstorm",
        "AccountDetails": "Sub-Ex",
        "RFDID": "201",
        "FromDate": "2016-05-07",
        "DaysPending": 3,
        "SOID": 1,
        "Status": ""
    }, {
        "ProjectDetails": "Zazio",
        "AccountDetails": "Bitwolf",
        "RFDID": "02389",
        "FromDate": "2015-09-06",
        "DaysPending": 8,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Tagtune",
        "AccountDetails": "Flexidy",
        "RFDID": "4",
        "FromDate": "2016-05-05",
        "DaysPending": 2,
        "SOID": 4,
        "Status": ""
    }, {
        "ProjectDetails": "Photobug",
        "AccountDetails": "Holdlamis",
        "RFDID": "89526",
        "FromDate": "2015-11-24",
        "DaysPending": 6,
        "SOID": 5,
        "Status": ""
    }, {
        "ProjectDetails": "Teklist",
        "AccountDetails": "Fintone",
        "RFDID": "58",
        "FromDate": "2016-01-08",
        "DaysPending": 1,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Skipstorm",
        "AccountDetails": "Konklux",
        "RFDID": "788",
        "FromDate": "2015-10-15",
        "DaysPending": 5,
        "SOID": 2,
        "Status": "Red"
    }, {
        "ProjectDetails": "Camimbo",
        "AccountDetails": "Pannier",
        "RFDID": "6940",
        "FromDate": "2016-08-20",
        "DaysPending": 8,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Eint",
        "AccountDetails": "Stronghold",
        "RFDID": "1651",
        "FromDate": "2016-08-28",
        "DaysPending": 2,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Tambee",
        "AccountDetails": "Tin",
        "RFDID": "28631",
        "FromDate": "2016-08-14",
        "DaysPending": 10,
        "SOID": 4,
        "Status": "Orange"
    }, {
        "ProjectDetails": "Ailane",
        "AccountDetails": "Fixflex",
        "RFDID": "90405",
        "FromDate": "2015-12-09",
        "DaysPending": 10,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Edgeify",
        "AccountDetails": "Wrapsafe",
        "RFDID": "3645",
        "FromDate": "2016-08-22",
        "DaysPending": 8,
        "SOID": 8,
        "Status": "Red"
    }, {
        "ProjectDetails": "Tagpad",
        "AccountDetails": "Bigtax",
        "RFDID": "173",
        "FromDate": "2015-12-06",
        "DaysPending": 2,
        "SOID": 5,
        "Status": ""
    }, {
        "ProjectDetails": "Jabbersphere",
        "AccountDetails": "Flexidy",
        "RFDID": "39",
        "FromDate": "2016-02-17",
        "DaysPending": 2,
        "SOID": 3,
        "Status": ""
    }, {
        "ProjectDetails": "Skinix",
        "AccountDetails": "Lotlux",
        "RFDID": "62165",
        "FromDate": "2016-01-07",
        "DaysPending": 7,
        "SOID": 3,
        "Status": ""
    }, {
        "ProjectDetails": "Viva",
        "AccountDetails": "Cardify",
        "RFDID": "65168",
        "FromDate": "2016-02-14",
        "DaysPending": 6,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Vinder",
        "AccountDetails": "It",
        "RFDID": "0928",
        "FromDate": "2015-09-17",
        "DaysPending": 5,
        "SOID": 4,
        "Status": ""
    }, {
        "ProjectDetails": "Realmix",
        "AccountDetails": "Redhold",
        "RFDID": "8704",
        "FromDate": "2016-07-31",
        "DaysPending": 9,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Yakidoo",
        "AccountDetails": "Lotlux",
        "RFDID": "32",
        "FromDate": "2016-06-16",
        "DaysPending": 8,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Skimia",
        "AccountDetails": "Temp",
        "RFDID": "9",
        "FromDate": "2015-09-30",
        "DaysPending": 3,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Quimm",
        "AccountDetails": "Andalax",
        "RFDID": "453",
        "FromDate": "2015-11-04",
        "DaysPending": 9,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Zooveo",
        "AccountDetails": "Tin",
        "RFDID": "119",
        "FromDate": "2016-01-15",
        "DaysPending": 4,
        "SOID": 3,
        "Status": ""
    }, {
        "ProjectDetails": "Voonyx",
        "AccountDetails": "Solarbreeze",
        "RFDID": "47683",
        "FromDate": "2016-01-07",
        "DaysPending": 6,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Browseblab",
        "AccountDetails": "Zoolab",
        "RFDID": "58",
        "FromDate": "2016-08-19",
        "DaysPending": 8,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Yotz",
        "AccountDetails": "Fintone",
        "RFDID": "5",
        "FromDate": "2015-09-26",
        "DaysPending": 2,
        "SOID": 8,
        "Status": ""
    }, {
        "ProjectDetails": "Ntags",
        "AccountDetails": "Bitwolf",
        "RFDID": "4",
        "FromDate": "2016-02-26",
        "DaysPending": 6,
        "SOID": 2,
        "Status": ""
    }, {
        "ProjectDetails": "Lazzy",
        "AccountDetails": "Flexidy",
        "RFDID": "201",
        "FromDate": "2015-12-13",
        "DaysPending": 7,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Meejo",
        "AccountDetails": "Asoka",
        "RFDID": "5000",
        "FromDate": "2016-05-19",
        "DaysPending": 8,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Skinte",
        "AccountDetails": "Stronghold",
        "RFDID": "593",
        "FromDate": "2016-01-15",
        "DaysPending": 2,
        "SOID": 10,
        "Status": "Red"
    }, {
        "ProjectDetails": "Viva",
        "AccountDetails": "Solarbreeze",
        "RFDID": "52",
        "FromDate": "2016-07-26",
        "DaysPending": 10,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Skipstorm",
        "AccountDetails": "Overhold",
        "RFDID": "068",
        "FromDate": "2015-09-18",
        "DaysPending": 3,
        "SOID": 4,
        "Status": ""
    }, {
        "ProjectDetails": "Myworks",
        "AccountDetails": "Temp",
        "RFDID": "68764",
        "FromDate": "2016-03-07",
        "DaysPending": 2,
        "SOID": 5,
        "Status": "Green"
    }, {
        "ProjectDetails": "Jaxnation",
        "AccountDetails": "Alphazap",
        "RFDID": "081",
        "FromDate": "2015-11-22",
        "DaysPending": 3,
        "SOID": 10,
        "Status": "Red"
    }, {
        "ProjectDetails": "Photojam",
        "AccountDetails": "Home Ing",
        "RFDID": "1",
        "FromDate": "2015-09-05",
        "DaysPending": 5,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Trudeo",
        "AccountDetails": "Aerified",
        "RFDID": "726",
        "FromDate": "2016-07-22",
        "DaysPending": 3,
        "SOID": 1,
        "Status": "Orange"
    }, {
        "ProjectDetails": "Wikido",
        "AccountDetails": "Toughjoyfax",
        "RFDID": "110",
        "FromDate": "2016-02-06",
        "DaysPending": 3,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Abatz",
        "AccountDetails": "Tin",
        "RFDID": "8",
        "FromDate": "2016-06-07",
        "DaysPending": 8,
        "SOID": 4,
        "Status": ""
    }, {
        "ProjectDetails": "Jabberstorm",
        "AccountDetails": "Sonair",
        "RFDID": "3",
        "FromDate": "2015-11-30",
        "DaysPending": 2,
        "SOID": 8,
        "Status": ""
    }, {
        "ProjectDetails": "Katz",
        "AccountDetails": "Cookley",
        "RFDID": "9",
        "FromDate": "2016-04-20",
        "DaysPending": 3,
        "SOID": 4,
        "Status": ""
    }, {
        "ProjectDetails": "Quinu",
        "AccountDetails": "Pannier",
        "RFDID": "3",
        "FromDate": "2016-01-20",
        "DaysPending": 1,
        "SOID": 3,
        "Status": ""
    }, {
        "ProjectDetails": "Einti",
        "AccountDetails": "Solarbreeze",
        "RFDID": "617",
        "FromDate": "2015-09-10",
        "DaysPending": 5,
        "SOID": 6,
        "Status": ""
    }, {
        "ProjectDetails": "Jatri",
        "AccountDetails": "Quo Lux",
        "RFDID": "38",
        "FromDate": "2016-03-06",
        "DaysPending": 2,
        "SOID": 1,
        "Status": ""
    }, {
        "ProjectDetails": "Thoughtstorm",
        "AccountDetails": "Flexidy",
        "RFDID": "07852",
        "FromDate": "2015-09-27",
        "DaysPending": 6,
        "SOID": 8,
        "Status": ""
    }, {
        "ProjectDetails": "BlogXS",
        "AccountDetails": "Konklab",
        "RFDID": "18",
        "FromDate": "2015-09-25",
        "DaysPending": 9,
        "SOID": 9,
        "Status": ""
    }, {
        "ProjectDetails": "Topicblab",
        "AccountDetails": "Pannier",
        "RFDID": "573",
        "FromDate": "2016-01-06",
        "DaysPending": 1,
        "SOID": 7,
        "Status": ""
    }, {
        "ProjectDetails": "Jaxspan",
        "AccountDetails": "Keylex",
        "RFDID": "844",
        "FromDate": "2016-08-19",
        "DaysPending": 2,
        "SOID": 1,
        "Status": ""
    }, {
        "ProjectDetails": "Devshare",
        "AccountDetails": "Sonsing",
        "RFDID": "7693",
        "FromDate": "2016-07-15",
        "DaysPending": 5,
        "SOID": 3,
        "Status": "Red"
    }, {
        "ProjectDetails": "Jabbercube",
        "AccountDetails": "Rank",
        "RFDID": "206",
        "FromDate": "2016-02-25",
        "DaysPending": 8,
        "SOID": 8,
        "Status": "Red"
    }, {
        "ProjectDetails": "Eidel",
        "AccountDetails": "Job",
        "RFDID": "98",
        "FromDate": "2016-01-02",
        "DaysPending": 6,
        "SOID": 10,
        "Status": ""
    }, {
        "ProjectDetails": "Mybuzz",
        "AccountDetails": "Tin",
        "RFDID": "241",
        "FromDate": "2016-05-13",
        "DaysPending": 10,
        "SOID": 6,
        "Status": "Puce"
    }, {
        "ProjectDetails": "Meeveo",
        "AccountDetails": "Cookley",
        "RFDID": "1",
        "FromDate": "2016-03-30",
        "DaysPending": 8,
        "SOID": 2,
        "Status": "Orange"
    }, {
        "ProjectDetails": "Devpulse",
        "AccountDetails": "Regrant",
        "RFDID": "414",
        "FromDate": "2016-04-06",
        "DaysPending": 6,
        "SOID": 9,
        "Status": ""
    }*/];

    $scope.tableParams = new ngTableParams({
        page: 1,
        count: $scope.users.length,
        sorting: {
            FromDate: 'dsc'
        }
    }, {
        counts: [],
        getData: function ($defer, params) {
            $scope.data = params.sorting() ? $filter('orderBy')($scope.users, params.orderBy()) : $scope.users;
            $scope.data = params.filter() ? $filter('filter')($scope.data, params.filter()) : $scope-data;
			//if($scope.data = ($scope.data == '')) $scope.data = "No Records Found"; else $scope.data = $scope.data;
			//alert($scope.data);
            $defer.resolve($scope.data);
        }
    });

});

var mainApp = angular.module("mainApp", []);
 mainApp.controller('appController', function($scope) {
	$scope.student = {
	   subjects:[
		  {id:1,name:"Demand Role1 sdfsdfsdf sdfsdfwrtwete yetyetyetrete ddgdfhgfhgfh et5erterteterte terteteghhtutryut uturrqwerqerqerqwer Demand Role1 sdfsdfsdf sdfsdfwrtwete yetyetyetrete ddgdfhgfhgfh et5erterteterte terteteghhtutryut uturrqwerqerqerqwer Demand Role1 sdfsdfsdf sdfsdfwrtwete yetyetyetrete ddgdfhgfhgfh et5erterteterte terteteghhtutryut uturrqwerqerqerqwer"},
		  {id:2,name:"Demand Role2"},
		  {id:3,name:"Demand Role3"},
		  {id:4,name:"Demand Role4"},
		  {id:5,name:"Demand Role5"},
		  {id:6,name:"Demand Role6"},
		  {id:7,name:"Demand Role7"},
		  {id:8,name:"Demand Role8"},
		  {id:9,name:"Demand Role9"},
		  {id:10,name:"Demand Role10"},
		  {id:11,name:"Demand Role11"},
		  {id:12,name:"Demand Role12"},
		  {id:13,name:"Demand Role13"},
		  {id:14,name:"Demand Role14"},
		  {id:15,name:"Demand Role15"},
		  {id:16,name:"Demand Role16"},
		  {id:17,name:"Demand Role17"},
		  {id:18,name:"Demand Role18"},
		  {id:19,name:"Demand Role19"},
		  {id:20,name:"Demand Role20"},
		  {id:21,name:"Demand Role21"},
		  {id:22,name:"Demand Role22"},
		  {id:23,name:"Demand Role23"},
		  {id:24,name:"Demand Role24"},
		  {id:25,name:"Demand Role25"}
		  
	   ]
	};
 });


$('table.stlTbl tbody tr').dblclick(function(){
	window.location.href='workflowRequestDetail.html';
})	
$('.boxInnerContent li').click(function(){$('.stlTbl').find('.input-filter').val('');})

/*$(function(){
	$('#scrollable-area').slimScroll({
		height: '400px',
		size: '5px',
		distance:'5px',
		alwaysVisible:true
	});
});*/
$(".boxCont ul.boxInnerContent li").click(function() {
  $(this).closest('ul').find('.active').removeClass('active');
  $(this).addClass('active');
});

/********** Scroll coode for the data table ********************/

// Change the selector if needed
var $table = $('table.scroll'),
	$bodyCells = $table.find('tbody tr:first').children(),colWidth;

// Adjust the width of thead cells when window resizes
$(window).resize(function() {
	// Get the tbody columns width array
	colWidth = $bodyCells.map(function() {
		return $(this).width();
	}).get();
	
	// Set the width of thead columns
	$table.find('thead tr').children().each(function(i, v) {
		$(v).width(colWidth[i]);
	});    
}).resize(); // Trigger resize handler


$(document).ready(function(){
/*$(".innerCustCheckbox").click(function()
{
		if($(this).hasClass("checkAll")){
			
			if ($(this).hasClass("unselected")) {
				$(this).parents('.dataLookUpTbl').find('.innerCustCheckbox').each(function(){
					$(this).removeClass("unselected").addClass("selected");
					$(this).closest(".checkBoxGroup").find("input").attr("checked", true);
					$(this).closest(".checkBoxGroup").find("input").prop("checked", true);
				});
		  	}
		  	else{
				$(this).parents('.dataLookUpTbl').find('.innerCustCheckbox').each(function(){
                    $(this).closest(".checkBoxGroup").find("input").attr("checked", false);
					$(this).closest(".checkBoxGroup").find("input").prop("checked", false);
					$(this).removeClass("selected").addClass("unselected");                                                     
				});
			}
			
			
		} 
			else{
			if($(this).hasClass("unselected"))
			{
				$(this).removeClass("unselected").addClass("selected");
				$(this).parents(".checkboxContainer").find("input").attr("checked",true);
				$(this).parents(".checkboxContainer").find("input").prop("checked",true);
			}
			else
			{
				if($(this).hasClass("selected"))
				{
					$(this).parents(".dataLookUpTbl").find('.checkBoxGroup .checkAll.innerCustCheckbox').removeClass('selected').addClass("unselected");
					$(this).parents(".checkboxContainer").find("input").attr("checked",false);
					$(this).parents(".checkboxContainer").find("input").prop("checked",false);
					$(this).removeClass("selected").addClass("unselected");
				}
			}
		}
		
});*/

$("#select_all").change(function(){  //"select all" change 
    $(".checkbox").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked status
});

})

/*** Tooltip ***/
$(document).ready(function(){
  $("[rel='tooltip']").tooltip();
})
/*** Tooltip ***/